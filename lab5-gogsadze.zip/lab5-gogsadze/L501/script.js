let head = document.head;
let list = document.querySelector('ul');
let li2 = document.querySelectorAll('li')[1];

console.log(head);
console.log(list);
console.log(li2);
