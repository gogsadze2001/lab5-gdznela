let models = [...document.querySelectorAll('#phone-container .model')].map(el => el.innerHTML);
console.log(models);